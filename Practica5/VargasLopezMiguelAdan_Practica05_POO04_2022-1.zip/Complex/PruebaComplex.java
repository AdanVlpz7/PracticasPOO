public class PruebaComplex{
	public static void main(String[] args) {
		//ComplexNumber aux;
		ComplexNumber n1 = new ComplexNumber(1,1);
		ComplexNumber n2 = new ComplexNumber(1,1);
		n1.PrintComplexNumber(n1.suma(n1,n2));
	}
}